package com.example.ruan.exceptions;

public class ExceptionPessoaSemRequisitos extends Exception{

}
