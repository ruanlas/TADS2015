package com.example.ruan.exceptions;

public class ExceptionEntradaInsuficiente extends Exception{

}
