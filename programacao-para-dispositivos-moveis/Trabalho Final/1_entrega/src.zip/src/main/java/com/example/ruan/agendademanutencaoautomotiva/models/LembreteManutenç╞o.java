package com.example.ruan.agendademanutencaoautomotiva.models;

import java.sql.Time;
import java.util.Date;
import java.util.TimeZone;

/**
 * Created by Ruan on 17/11/2017.
 */

public class LembreteManutenção {
    private long id;
    private Date dataAgendamento;
    private String notas;
    private double valor;
    private TimeZone horarioAgendamento;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public LembreteManutenção(){

    }

    public Date getDataAgendamento() {
        return dataAgendamento;
    }

    public void setDataAgendamento(Date dataAgendamento) {
        this.dataAgendamento = dataAgendamento;
    }

    public String getNotas() {
        return notas;
    }

    public void setNotas(String notas) {
        this.notas = notas;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public TimeZone getHorarioAgendamento() {
        return horarioAgendamento;
    }

    public void setHorarioAgendamento(TimeZone horarioAgendamento) {
        this.horarioAgendamento = horarioAgendamento;
    }
}
