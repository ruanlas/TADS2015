package com.example.ruan.agendademanutencaoautomotiva.database;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;

import com.example.ruan.agendademanutencaoautomotiva.models.LembreteManutenção;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

/**
 * Created by Ruan on 17/11/2017.
 */

public class DBHelper {
    private static final String DATABASE_NAME = "lembretes_manutencao.db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "tabela_lembrete";

    private Context context;
    private SQLiteDatabase db;

    private SQLiteStatement insertStmt, deleteStmt;
    private static final String INSERT = "insert into "+TABLE_NAME+" (data_agendamento, horario_agendamento, notas, valor) values (?, ?, ?, ?)";
    private static final String DELETE = "delete from "+TABLE_NAME+" where id = ?";

    public DBHelper(Context context){
        this.context = context;
        OpenHelper openHelper = new OpenHelper(this.context);
        this.db = openHelper.getWritableDatabase();
        this.insertStmt = this.db.compileStatement(INSERT);
        this.deleteStmt = this.db.compileStatement(DELETE);
    }

    public long insert(LembreteManutenção lembreteManutenção){
        this.insertStmt.bindString(1,lembreteManutenção.getDataAgendamento());
        this.insertStmt.bindString(2,lembreteManutenção.getHorarioAgendamento());
        this.insertStmt.bindString(3, lembreteManutenção.getNotas());
        this.insertStmt.bindDouble(4, lembreteManutenção.getValor());
        return this.insertStmt.executeInsert();
    }

    public int delete(LembreteManutenção lembreteManutenção){
        this.deleteStmt.bindLong(1,lembreteManutenção.getId());
        return this.deleteStmt.executeUpdateDelete();
    }

    public void deleteAll(){
        this.db.delete(TABLE_NAME, null, null);
    }

    public List<LembreteManutenção> queryGetAll(){
        List<LembreteManutenção> list = new ArrayList<LembreteManutenção>();
        try {
            Cursor cursor = this.db.query(TABLE_NAME, new String[]{"id", "data_agendamento", "horario_agendamento", "notas", "valor"},
                    null, null, null, null, null, null);
            int nregistros = cursor.getCount();

            if (nregistros != 0){
                cursor.moveToFirst();
                do {
                    LembreteManutenção lembreteManutenção = new LembreteManutenção();
                    lembreteManutenção.setId(cursor.getLong(0));
                    lembreteManutenção.setDataAgendamento(cursor.getString(1));
                    lembreteManutenção.setHorarioAgendamento(cursor.getString(2));
                    lembreteManutenção.setNotas(cursor.getString(3));
                    lembreteManutenção.setValor(cursor.getDouble(4));

                    list.add(lembreteManutenção);
                }while (cursor.moveToNext());

                if (cursor != null && !cursor.isClosed()){
                    cursor.close();
                }
                return list;
            }else {
                return null;
            }
        }catch (Exception err){
            return null;
        }

    }

    private static class OpenHelper extends SQLiteOpenHelper{
        OpenHelper(Context context){
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            String sql = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME +
                    " (id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "data_agendamento TEXT, " +
                    "horario_agendamento TEXT, " +
                    "notas TEXT, " +
                    "valor DOUBLE); ";
            db.execSQL(sql);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
            onCreate(db);
        }
    }
}
