package com.example.ruan.agendademanutencaoautomotiva.controller;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.ruan.agendademanutencaoautomotiva.R;
import com.example.ruan.agendademanutencaoautomotiva.database.DBHelper;
import com.example.ruan.agendademanutencaoautomotiva.models.LembreteManutenção;

import java.util.ArrayList;

/**
 * Created by Ruan on 23/11/2017.
 */

public class ListarManutencoesActivity extends AppCompatActivity {
    private DBHelper dbHelper;
    private ListView listManutencoes;
    private ArrayList<LembreteManutenção> listaLembretes = null;
    private ArrayAdapter<LembreteManutenção> adapter = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listar_manutencoes);

        dbHelper = new DBHelper(this);
        listManutencoes = (ListView)findViewById(R.id.lstView_manutencoes);
        listaLembretes = (ArrayList<LembreteManutenção>)dbHelper.queryGetAll();

        if(listaLembretes != null){
            adapter = new ArrayAdapter<LembreteManutenção>(this,android.R.layout.simple_list_item_1, listaLembretes);
            listManutencoes.setAdapter(adapter);
        }

    }

    public void btnVoltar(View view){
        Intent intent = new Intent(ListarManutencoesActivity.this, MainActivity.class );
        intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(intent);
        finish();
    }
}