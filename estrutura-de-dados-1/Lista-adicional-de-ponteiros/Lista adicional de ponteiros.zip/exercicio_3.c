#include<stdio.h>
#include<stdlib.h>

int main(){
    int n = 0;
    printf("Digite um n�mero para definir o tamanho do vetor: ");
    scanf("%d", &n);
    int vetor[n];
    printf("\nVetor criado com sucesso!!\n");
    return 0;
}
